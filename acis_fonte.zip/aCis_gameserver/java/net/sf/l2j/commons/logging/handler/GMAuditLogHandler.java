package net.sf.l2j.commons.logging.handler;

import java.io.IOException;
import java.util.logging.FileHandler;

public class GMAuditLogHandler extends FileHandler
{
	public GMAuditLogHandler() throws IOException, SecurityException
	{
		super();
	}
}