package net.sf.l2j.commons.logging.handler;

import java.io.IOException;
import java.util.logging.FileHandler;

public class ChatLogHandler extends FileHandler
{
	public ChatLogHandler() throws IOException, SecurityException
	{
		super();
	}
}