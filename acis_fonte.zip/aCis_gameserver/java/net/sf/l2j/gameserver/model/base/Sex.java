package net.sf.l2j.gameserver.model.base;

public enum Sex
{
	MALE,
	FEMALE,
	ETC;
}