package net.sf.l2j.gameserver.model.base;

/**
 * ClassType Enum
 * @author Tempy
 */
public enum ClassType
{
	FIGHTER,
	MYSTIC,
	PRIEST
}