package net.sf.l2j.gameserver.model.item.type;

/**
 * Created for allow comparing different item types
 * @author DS
 */
public interface ItemType
{
	public int mask();
}